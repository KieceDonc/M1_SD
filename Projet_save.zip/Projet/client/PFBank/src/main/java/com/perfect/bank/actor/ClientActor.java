package sd.akka.actor;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.AbstractActor;
import akka.actor.Props;
import akka.pattern.Patterns;
import java.time.Duration;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;

import akka.event.LoggingAdapter;
import akka.event.Logging;

public class ClientActor extends AbstractActor {

    private LoggingAdapter log = Logging.getLogger(this.getContext().system(), this);

    private ActorRef bankActor;

    private int UID = -1;

    public ClientActor(ActorRef bankActor) {
        this.bankActor = bankActor;
        this.getUID();
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder().build();
    }

    public int getUID() {
        try {
            if (this.UID < 0) {
                CompletionStage<Object> result = Patterns.ask(bankActor,
                        new BankActor.GetUID(),
                        Duration.ofSeconds(10));
                this.UID = (int) result.toCompletableFuture().get();
                this.log.info("[Client] UID reçu : " + this.UID);
            }

            return this.UID;
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return -1;
    }

    public static Props props(ActorRef bankActor) {
        return Props.create(ClientActor.class, bankActor);
    }

    public static class GetUID {

        public GetUID() {
        }
    }

    public class Withdraw extends BankOperation {

        public Withdraw(double amount) {
            super(amount);
        }
    }

    public class Deposit extends BankOperation {

        public Deposit(double amount) {
            super(amount);
        }
    }

    private class BankOperation {

        private double amount;

        public BankOperation(double amount) {
            this.amount = amount;
        }

        public double getAmount() {
            return this.amount;
        }
    }
}