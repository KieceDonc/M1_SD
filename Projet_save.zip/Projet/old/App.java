package sd.akka;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import sd.akka.actor.BankActor;
import sd.akka.actor.ClientActor;

public class App {

    // mvn exec:java -Dexec.mainClass=sd.akka.App
    public static void main(String[] args) {

        ActorSystem actorSystem = ActorSystem.create();
        ActorRef bankActor = actorSystem.actorOf(BankActor.props());
        ActorRef clientActor = actorSystem.actorOf(ClientActor.props(bankActor));
    }
}
