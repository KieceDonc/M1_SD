package sd.akka.actor;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;
import akka.event.LoggingAdapter;
import akka.event.Logging;

public class BankActor extends AbstractActor {

    private LoggingAdapter log = Logging.getLogger(this.getContext().system(), this);

    private int clientLastUID = 0;

    public BankActor() {

    }

    @Override
    public Receive createReceive() {
        return receiveBuilder().match(GetUID.class, message -> getUID(getSender())).build();
    }

    public synchronized void getUID(ActorRef actor) {
        actor.tell(this.clientLastUID++, this.getSelf());
    }

    public static Props props() {
        return Props.create(BankActor.class);
    }

    public class GetBanker {

    }

    public class ClientBalance {

    }

    public static class GetUID {

        public GetUID() {
        }
    }

}
